  <!--Subscribe Section-->
    <section class="subscribe-section">
    	<div class="auto-container">
        	<!--Form Container-->
            <div class="form-container">
            	<div class="row clearfix">
                
                    <div class="col-lg-4 col-md-12 col-xs-12">
                        <h5>Subcripción</h5>
                    	<h3>Novedades acerca de Nuevos Productos</h3>
                    </div>
                    <div class="col-lg-8 col-md-12 col-xs-12">
                        <div class="subscribe-form">
                        	<form method="post" action="#">
                            	<div class="form-group">
                                	<input type="email" name="email"  placeholder="Ingrese su Correo" required>
                                    <button type="submit" class="theme-btn btn-style-three">Enviar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>