
    	<div class="header-top">
        	<div class="auto-container">
            	<div class="clearfix">
                    
                    <!--Top Left-->
                    <div class="top-left">
                    	<!--social-icon-->
                        <div class="social-icon clearfix">
                        	<a href="#"><span class="fa fa-facebook"></span></a>
                            <a href="#"><span class="fa fa-twitter"></span></a>                            
                            <a href="#"><span class="fa fa-instagram"></span></a>
                        </div>
                    </div>
                    
                 
                    
                </div>
                
            </div>
        </div><!-- Header Top End -->