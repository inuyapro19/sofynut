@extends('front.layout')

@section('content')
 <h1>Hola</h1> 
@stop