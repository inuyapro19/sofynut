   <header class="main-header">
    	
    	<?php echo $__env->make('front.partial.top_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        
        <!-- Main Box -->
    	<div class="main-box">
        	<div class="auto-container">
            	<div class="outer-container clearfix">
                    <!--Logo Box-->
                    <div class="logo-box">
                        <div class="logo"><a href="/"><img src="<?php echo e(asset('front/img/logo.jpg')); ?>" width="120" alt=""></a></div>
                    </div>
                    
                    <!--Nav Outer-->
                    <?php echo $__env->make('front.partial.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        
                    </div><!--Nav Outer End-->
                    
                    
                    
                    <!-- Hidden Nav Toggler -->
                    <div class="nav-toggler">
                    <button class="hidden-bar-opener"><span class="icon fa fa-bars"></span></button>
                    </div><!-- / Hidden Nav Toggler -->
                    
            	</div>    
            </div>
        </div>
    
    </header>
<?php echo $__env->make('front.partial.menu_responsive', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>