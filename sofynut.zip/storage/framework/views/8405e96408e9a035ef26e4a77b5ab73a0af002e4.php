<li class="<?php echo e(Request::is('productos*') ? 'active' : ''); ?>">
    <a href="<?php echo route('productos.index'); ?>"><i class="fa fa-edit"></i><span>Productos</span></a>
</li>

<li class="<?php echo e(Request::is('sliders*') ? 'active' : ''); ?>">
    <a href="<?php echo route('sliders.index'); ?>"><i class="fa fa-edit"></i><span>Sliders</span></a>
</li>

<li class="<?php echo e(Request::is('informacions*') ? 'active' : ''); ?>">
    <a href="<?php echo route('informacions.edit',1); ?>"><i class="fa fa-edit"></i><span>Informacions</span></a>
</li>

