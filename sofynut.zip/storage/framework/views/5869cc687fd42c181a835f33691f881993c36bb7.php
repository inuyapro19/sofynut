                        <div class="nav-outer clearfix">
                            <!-- Main Menu -->
                            <nav class="main-menu">
                                <div class="navbar-header">
                                    <!-- Toggle Button -->    	
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                </div>
                                
                                <div class="navbar-collapse collapse clearfix">
                                    <ul class="navigation clearfix">
                                        <li class="activate"><a href="<?php echo e(route('inicio')); ?>">Inicio</a></li>

                                        <li><a href="<?php echo e(route('nosostros')); ?>">Quiénes Somos</a></li>                                  
                                       
                                        <li class="dropdown"><a href="#">Productos</a>
                                            <ul>
                                                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e(route('producto_single',$prod_menu->slug)); ?>"><?php echo e($prod_menu->nombre); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                           
                                            </ul>
                                        </li>
                                       
                                        <li><a href="<?php echo e(route('form_contacto')); ?>">Contacto</a></li>
                                     </ul>
                                     
                                   
                                </div>
                            </nav><!-- Main Menu End-->