<!-- Nombre Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nombre', 'Nombre:'); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::text('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Telefono Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('telefono', 'Telefono:'); ?>

    <?php echo Form::text('telefono', null, ['class' => 'form-control']); ?>

    <div class="help-block"><span>Ingrese numero de teléfono sin el +56</span></div>
</div>

<!-- Telefono2 Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('telefono2', 'Teléfono #2:'); ?>

    <?php echo Form::text('telefono2', null, ['class' => 'form-control']); ?>

</div>

<!-- Quienes Somos Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('quienes_somos', 'Quienes Somos:'); ?>

    <?php echo Form::textarea('quienes_somos', null, ['class' => 'form-control','id'=>'quienes_somos']); ?>

</div>

<!-- Direcion Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('direcion', 'Direcion:'); ?>

    <?php echo Form::text('direcion', null, ['class' => 'form-control']); ?>

</div>

<!-- Facebook Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('facebook', 'Facebook:'); ?>

    <?php echo Form::text('facebook', null, ['class' => 'form-control','placeholder'=>'Ingrese la Url']); ?>

</div>

<!-- Twitter Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('twitter', 'Twitter:'); ?>

    <?php echo Form::text('twitter', null, ['class' => 'form-control','placeholder'=>'Ingrese la Url']); ?>

</div>

<!-- Instagram Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('instagram', 'Instagram:'); ?>

    <?php echo Form::text('instagram', null, ['class' => 'form-control','placeholder'=>'Ingrese la Url']); ?>

</div>

<!-- Mapa Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('mapa', 'Mapa:'); ?>

    <?php echo Form::textarea('mapa', null, ['class' => 'form-control','placeholder'=>'Ingrese el iframe del mapa']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('productos.index'); ?>" class="btn btn-default">Volver</a>
</div>
