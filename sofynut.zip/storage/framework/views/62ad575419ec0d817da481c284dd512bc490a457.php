<?php $__env->startComponent('mail::message'); ?>
#Mensaje enviado de Sofynut
![logo](<?php echo e(asset('/front/img/logo.jpg')); ?>)
<?php $__env->startComponent('mail::table'); ?>
    |        |          |
    |--------|----------|
	|Nombre  | <?php echo e(strtoupper($nombre).' '.strtoupper($apellido)); ?> |		
	|Email  | <?php echo e($email); ?> |	
	|Teléfono | <?php echo e($telefono); ?> |	
	|Mensaje | <?php echo e($mensaje); ?> |
	
<?php echo $__env->renderComponent(); ?>

Mensaje generado autromaticamente,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
