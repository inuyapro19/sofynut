<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>SofyNut | <?php echo $__env->yieldContent('titulo'); ?> </title>
<!-- Stylesheets -->
<link href="<?php echo e(asset('front/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('front/css/revolution-slider.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('front/css/style.css')); ?>" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link href="<?php echo e(asset('front/css/responsive.css')); ?>" rel="stylesheet">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>
<body>
	<div class="page-wrapper">
		<?php echo $__env->make('front.partial.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	

		<div class="contenedor">
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	
		<?php echo $__env->make('front.partial.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</div>
	<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-long-arrow-up"></span></div>


	<script src="<?php echo e(asset('front/js/jquery.js')); ?>"></script> 
	<script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('front/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
	<script src="<?php echo e(asset('front/js/revolution.min.js')); ?>"></script>
	<script src="<?php echo e(asset('front/js/jquery.fancybox.pack.js')); ?>"></script>
	<script src="<?php echo e(asset('front/js/jquery.fancybox-media.js')); ?>"></script>
	<script src="<?php echo e(asset('front/js/jquery.countdown.js')); ?>"></script>
	<script src="<?php echo e(asset('front/js/owl.js')); ?>"></script>
	<script src="<?php echo e(asset('front/js/wow.js')); ?>"></script>
	<script src="<?php echo e(asset('front/js/script.js')); ?>"></script>
</body>
</html>