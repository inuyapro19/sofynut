<!-- Nombre Field -->
<div class="form-group col-sm-8">
    <?php echo Form::label('nombre', 'Nombre:'); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control']); ?>

</div>

<!-- Descripcion Field -->
<div class="form-group col-sm-8">
    <?php echo Form::label('descripcion', 'Descripcion:'); ?>

    <?php echo Form::text('descripcion', null, ['class' => 'form-control']); ?>

</div>
<!-- Descripcion Field -->
<div class="form-group col-sm-8">
    <?php echo Form::label('imagen', 'Imagen:'); ?>

    <?php echo Form::file('imagen'); ?>

</div>
<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('productos.index'); ?>" class="btn btn-default">Volver</a>
</div>
