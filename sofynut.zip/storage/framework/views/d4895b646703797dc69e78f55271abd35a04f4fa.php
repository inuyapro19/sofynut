<?php $__env->startSection('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('vendor/tinymce/')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Informacion
        </h1>
   </section>
   <div class="content">
       <?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <div class="box box-primary">
           <div class="box-body">
               <div class="row">
                   <?php echo Form::model($informacion, ['route' => ['informacions.update', $informacion->id], 'method' => 'patch']); ?>


                        <?php echo $__env->make('informacions.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                   <?php echo Form::close(); ?>

               </div>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
 <script src="<?php echo e(asset('vendor/tinymce/tinymce.min.js')); ?>"></script>
 <script>tinymce.init({ selector:'#quienes_somos' });</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>